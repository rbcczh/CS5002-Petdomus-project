"""final URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app01 import views

urlpatterns = [
    # visitor home page and profile page.
    path('index/', views.index),
    path('general_profile/', views.general_profile),

    # user home page.
    path('user/index/', views.user_index),

    # user profile.
    path('user/user_profile/', views.user_profile),

    # user register page and login page.
    path('user/register/', views.register),
    path('user/login/', views.login),

    # admin register page, login page and admin home page.
    path('admin/register/', views.admin_register),
    path('admin/login/', views.admin_login),
    path('admin/index/', views.admin_index),

    # admin profile page.
    path('profile/', views.profile),
    path('profile/add/', views.profile_add),
    path('profile/<int:nid>/edit/', views.profile_edit),
    path('profile/<int:nid>/delete/', views.profile_delete),

    # user contact page.
    path('user/contact/', views.user_contact),

    # general contact page.
    path('contact/', views.contact),
]
