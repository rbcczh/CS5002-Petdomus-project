from django.test import TestCase
from app01.models import UserInfo, Profile, AdminInfo


# Create your tests here.
class PetdomusTestCase(TestCase):
    def setup(self):
        pass

    def test_index(self):
        response = self.client.post('/index/')
        self.assertEqual(response.status_code, 200)

    def test_user_register(self):
        UserInfo(
            name='name1',
            password='mypassword'
        ).save()

        self.assertEqual(
            UserInfo.objects.filter(name='name1').count(),
            1,
            'Filed'
        )

    def test_admin_login(self):
        AdminInfo(
            admin_name='admin1',
            admin_password='mypassword'
        ).save()

        self.assertEqual(
            AdminInfo.objects.filter(admin_name='admin1').count(),
            1,
            'Filed'
        )

    def test_login(self):
        self.login_user = {'name': 'name1', 'password': 'mypassword'}
        response = self.client.post('/user/index/', data=self.login_user)
        self.assertEqual(response.status_code, 200)

    def test_profile_add(self):
        Profile(
            pet_name='Mercy',
            type='1',
            breed='N/A',
            gender='1',
            age='3',
            description='N/A'
        ).save()

        self.assertEqual(
            Profile.objects.filter(pet_name='Mercy').count(),
            1,
            'Filed'
        )

    def test_contact(self):
        response = self.client.post('/contact/')
        self.assertEqual(response.status_code, 200)
