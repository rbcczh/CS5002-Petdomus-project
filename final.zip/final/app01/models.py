from django.db import models


# Create your models here.
class UserInfo(models.Model):
    """ User information database"""
    name = models.CharField(max_length=32)
    password = models.CharField(max_length=64)


class Profile(models.Model):
    """ Pets information database"""
    pet_name = models.CharField(max_length=32, verbose_name="pet Name")
    type_choices = (
        (1, 'cat'),
        (2, 'dog'),
        (3, 'rabbit'),
        (4, 'rodent'),
        (5, 'others'),
    )
    type = models.SmallIntegerField(verbose_name="type", choices=type_choices, default=5)
    breed = models.CharField(max_length=64, verbose_name="breed")
    gender_choices = (
        (1, 'male'),
        (2, 'female'),
        (3, 'unknown'),
    )
    gender = models.SmallIntegerField(verbose_name="gender", choices=gender_choices, default=3)
    age = models.IntegerField(verbose_name="age", null=True, blank=True)
    description = models.CharField(max_length=200, verbose_name='description', null=True, blank=True)


class AdminInfo(models.Model):
    """ Admin information database"""
    admin_name = models.CharField(max_length=32)
    admin_password = models.CharField(max_length=64)
