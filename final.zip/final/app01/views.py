from django.forms import models
from django.shortcuts import render, HttpResponse, HttpResponseRedirect, redirect
from app01.models import UserInfo, Profile, AdminInfo
from django import forms
import copy
from django.core.exceptions import ValidationError


# Create your views here.
def index(request):
    """
    Visitor home page.
    :param request:
    :return: index.html
    """
    return render(request, 'index.html')


def register(request):
    """
    User register page.
    If the username has been registered or input an empty name, the system will report
    error message.
    After successfully registered, it will return to the login page.
    :param request:
    :return:
    """
    if request.method == "POST":
        name = request.POST.get('name')
        password = request.POST.get('password')
        user = UserInfo()
        select_name = UserInfo.objects.filter(name=name).exists()
        if name:
            if select_name:
                return render(request, 'user/register.html',
                              {'message': 'This name has been registered'})
            else:
                user.name = name
                user.password = password
                user.save()
                return HttpResponseRedirect('/user/login/')
        else:
            return render(request, 'user/register.html',
                          {'message': 'Please input username'})
    return render(request, 'user/register.html')


class LoginForm(forms.Form):
    """
    Format the login form.
    """
    username = forms.CharField(
        label='Username',
        widget=forms.TextInput(attrs={"class": "form-control"}),
        required=True
    )
    password = forms.CharField(
        label='Password',
        widget=forms.PasswordInput(attrs={"class": "form-control"}),
        required=True
    )


def login(request):
    """
    Login page.
    If the username and password are correct, it will go to the user home page,
    otherwise, it will report the error message.
    :param request:
    :return:
    """
    if request.method == "GET":
        form = LoginForm()
        return render(request, 'user/login.html', {"form": form})

    form = LoginForm(data=request.POST)
    error_msg = ''
    if form.is_valid():
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']
        try:
            if username and password:
                user = UserInfo.objects.filter(name=username, password=password).first()
                if user:
                    request.session['is_login'] = True
                    request.session['user_id'] = user.id
                    request.session['username'] = user.name
                    return redirect('/user/index/')
            else:
                error_msg = "Wrong password!"
        except:
            error_msg = "User doesn't exist!"
    return render(request, 'user/login.html', {"form": form, "error_msg": error_msg})


def user_index(request):
    """
    User home page.
    :param request:
    :return:
    """
    return render(request, 'user/user_index.html')


def admin_register(request):
    """
    Admin register page.
    If the admin name has been registered or input an empty name, the system will report
    error message.
    After successfully registered, it will return to the admin login page.
    :param request:
    :return:
    """
    if request.method == "POST":
        name = request.POST.get('admin_name')
        password = request.POST.get('admin_password')
        admin = AdminInfo()
        select_name = AdminInfo.objects.filter(admin_name=name).exists()
        if name:
            if select_name:
                return render(request, 'admin/admin_register.html',
                              {'message': 'This name has been registered'})
            else:
                admin.admin_name = name
                admin.admin_password = password
                admin.save()
                return HttpResponseRedirect('/admin/login/')
        else:
            return render(request, 'admin/admin_register.html',
                          {'message': 'Please input admin name'})

    return render(request, 'admin/admin_register.html')


class AdminLoginForm(forms.Form):
    """
    Format admin login page.
    """
    admin = forms.CharField(
        label='Admin',
        widget=forms.TextInput(attrs={"class": "form-control"}),
        required=True
    )
    password = forms.CharField(
        label='Password',
        widget=forms.PasswordInput(attrs={"class": "form-control"}),
        required=True
    )


def admin_login(request):
    """
    Admin login page.
    If the admin name and password are correct, it will go to the user home page,
    otherwise, it will report the error message.
    :param request:
    :return:
    """
    if request.method == "GET":
        form = AdminLoginForm()
        return render(request, 'admin/admin_login.html', {"form": form})

    form = AdminLoginForm(data=request.POST)
    error_msg = ''
    if form.is_valid():
        admin = form.cleaned_data['admin']
        password = form.cleaned_data['password']
        try:
            admin = AdminInfo.objects.get(admin_name=admin)
            if admin.admin_password == password:
                return HttpResponseRedirect('/admin/index/')
            else:
                error_msg = "Wrong password!"
        except:
            error_msg = "User doesn't exist!"
    return render(request, 'admin/admin_login.html', {"form": form, "error_msg": error_msg})


def admin_index(request):
    """
    Admin home page.
    :param request:
    :return:
    """
    return render(request, 'admin/admin_index.html')


def profile(request):
    """Show profile list and some functions"""

    # select * from table order by level asc(desc if '-type')
    queryset = Profile.objects.all().order_by('id')

    return render(request, 'profile.html', {"queryset": queryset})


class ProfileModelForm(forms.ModelForm):
    """Use ModelForm to get data from the database"""

    class Meta:
        model = Profile
        fields = "__all__"
        widgets = {
            "pet_name": forms.TextInput(attrs={"class": "form-control"}),
            "type": forms.Select(attrs={"class": "form-control"}),
            "breed": forms.TextInput(attrs={"class": "form-control"}),
            "gender": forms.Select(attrs={"class": "form-control"}),
            "age": forms.TextInput(attrs={"class": "form-control"}),
            "description": forms.TextInput(attrs={"class": "form-control"}),
        }


def profile_add(request):
    """Add new pets' information to Profile List"""
    if request.method == "GET":
        form = ProfileModelForm()
        return render(request, 'profile_add.html', {'form': form})

    form = ProfileModelForm(data=request.POST)
    if form.is_valid():
        # If the data is valid, save datas.
        form.save()
        return redirect('/profile/')
    else:
        # If the data is invalid
        return render(request, 'profile_add.html', {'form': form})


def profile_delete(request, nid):
    """Delete the data from Profile List"""
    Profile.objects.filter(id=nid).delete()
    return redirect('/profile/')


def profile_edit(request, nid):
    """Edit the data in Profile List"""
    row_object = Profile.objects.filter(id=nid).first()
    if request.method == 'GET':
        # Get data which we want to edit from database.
        form = ProfileModelForm(instance=row_object)
        return render(request, 'profile_edit.html', {'form': form})

    # Update data in the selected row, instead of creating a new row
    # instance represents the object you are currently operating on
    form = ProfileModelForm(data=request.POST, instance=row_object)
    if form.is_valid():
        # If the data is valid, save datas.
        form.save()
        return redirect('/profile/')
    else:
        # If the data is invalid
        return render(request, 'profile_edit.html', {'form': form})


def user_profile(request):
    """ User profile page"""
    queryset = Profile.objects.all().order_by('id')

    return render(request, 'user/user_profile.html', {"queryset": queryset})


def general_profile(request):
    """ Visitor profile page"""
    queryset = Profile.objects.all().order_by('id')

    return render(request, 'general_profile.html', {"queryset": queryset})


def user_contact(request):
    """ User contact information page"""
    return render(request, 'user/user_contact.html')


def contact(request):
    """ Contact information page"""
    return render(request, 'contact.html')
